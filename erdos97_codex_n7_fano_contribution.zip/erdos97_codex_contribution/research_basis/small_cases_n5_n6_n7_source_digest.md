# Source digest: small cases n=5, n=6, n=7

This is the research basis used for the repo contribution.

- For `n=5`, every witness row is all other vertices, so any two rows share three targets. This violates the two-circle intersection cap.
- For `n=6`, write `W_i = V \ {i, f(i)}`. Comparing `W_i` with `W_{f(i)}` gives at least three common selected witnesses. This violates the two-circle intersection cap.
- For `n=7`, counting forces equality in the pairwise cap. Every row pair intersects in exactly two vertices and every vertex has witness indegree four. The common-intersection map on the 21 chords is a permutation. Perpendicularity of each chord to its image produces an odd-cycle contradiction.

The repo bundle focuses on the `n=7` part because the current repository already records `n <= 6` and the Fano equality case, but not the final odd-cycle obstruction as a tested theorem.

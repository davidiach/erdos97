# Codex instructions: n=7 Fano enumeration contribution

Target repo: `davidiach/erdos97`.

## Goal

Apply a finite, exact n=7 contribution that addresses issue #2, “Enumerate all n=7 Fano-incidence cyclic labelings up to dihedral symmetry.”

The contribution does **not** claim a full proof of Erdős #97 and does **not** claim a counterexample. It proves that the selected-witness n=7 equality case is obstructed by radical-axis perpendicularity cycles.

## Apply

From the repository root, either copy `overlay/` into the repo root or apply the patch:

```bash
git apply patches/n7_fano_contribution.patch
```

If copying manually, map paths as follows:

```text
overlay/src/erdos97/n7_fano.py                              -> src/erdos97/n7_fano.py
overlay/scripts/enumerate_n7_fano.py                       -> scripts/enumerate_n7_fano.py
overlay/tests/test_n7_fano.py                              -> tests/test_n7_fano.py
overlay/docs/n7-fano-enumeration.md                        -> docs/n7-fano-enumeration.md
overlay/docs/n7-fano-obstruction.md                        -> docs/n7-fano-obstruction.md
overlay/data/incidence/n7_fano_dihedral_representatives.json -> data/incidence/n7_fano_dihedral_representatives.json
```

## Validate

Run:

```bash
python scripts/enumerate_n7_fano.py --summary
python scripts/enumerate_n7_fano.py --check-data data/incidence/n7_fano_dihedral_representatives.json --summary
pytest -q tests/test_n7_fano.py
pytest -q
```

Expected new-test result from this bundle:

```text
5 passed
```

Expected core counts:

```text
labelled_fano_planes: 30
pointed_fano_patterns: 720
dihedral_classes: 54
dihedral_orbit_size_distribution: {"2": 3, "14": 51}
all_pattern_cycle_type_counts: {"7+7+7": 720}
dihedral_class_cycle_type_counts: {"7+7+7": 54}
all_classes_obstructed: true
```

## Suggested follow-up edits

After tests pass, link `docs/n7-fano-enumeration.md` from `README.md`, `STATE.md`, and `docs/claims.md`. Suggested wording:

```text
The selected-witness incidence method rules out n <= 7. In the n=7 equality case, the 720 pointed Fano patterns fall into 54 cyclic-dihedral classes; in every case the common-witness chord map has cycle type 7+7+7, so the required perpendicularity relation has an odd cycle, impossible for nonzero Euclidean chords. See docs/n7-fano-enumeration.md.
```

## Suggested PR title

```text
Enumerate and obstruct the n=7 Fano-incidence equality case
```

## Suggested PR body

```text
This adds a finite n=7 enumerator, machine-readable representatives, tests, and documentation.

Highlights:
- enumerates 30 labelled Fano planes;
- enumerates 720 pointed equality families T_i with i in T_i;
- quotients them to 54 cyclic-dihedral representatives;
- records the induced radical-axis perpendicularity constraints for every representative;
- verifies every labelled family has chord-cycle type 7+7+7, giving an odd-cycle perpendicularity obstruction.

This resolves the n=7 selected-witness equality branch only. It does not claim a general proof or a counterexample.
```

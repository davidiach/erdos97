# erdos97 Codex contribution bundle

This ZIP is a Codex-ready contribution for `davidiach/erdos97`.

It targets the open n=7 Fano-incidence enumeration task and adds a tested exact finite obstruction:

- `overlay/src/erdos97/n7_fano.py`: dependency-free incidence helpers, Fano enumeration, and chord-permutation obstruction logic.
- `overlay/scripts/enumerate_n7_fano.py`: CLI to regenerate/check the JSON artifact.
- `overlay/tests/test_n7_fano.py`: pytest coverage for the counts, the full 720-family obstruction, and the checked-in artifact.
- `overlay/docs/n7-fano-enumeration.md`: human-readable proof and reproduction note.
- `overlay/data/incidence/n7_fano_dihedral_representatives.json`: 54 canonical dihedral representatives with all induced perpendicularity constraints.
- `patches/n7_fano_contribution.patch`: git-applyable patch containing the same overlay files.

Start with `CODEX_INSTRUCTIONS.md`.

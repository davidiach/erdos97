#!/usr/bin/env python3
"""Adaptive free-row angle search: move missing obligations, not a fixed seed.
Numerical discovery only. Positivity is not a planar-realization certificate.
"""
from __future__ import annotations
import argparse,itertools,json,sys,time,platform
from pathlib import Path
import numpy as np,scipy
from chain_angle_completion import Engine,seed,compatible

def run(a):
    start=time.monotonic();rng=np.random.default_rng(a.seed);order,rows,_=seed(a.orbits);n=len(order)
    
    if a.metric_closure:
        from closed_angle_engine import ClosedEngine
        e=ClosedEngine(n)
    else:e=Engine(n)
    current=e.solve(rows)
    if not current.success or current.x[-1]<=1e-7:raise RuntimeError('initial angle model not strictly feasible')
    pools={i:list(itertools.combinations([j for j in range(n)if j!=i],4))for i in range(n)}
    matrices={}
    for i,pool in pools.items():
        pairs=list(itertools.combinations([j for j in range(n)if j!=i],2));pidx={P:k for k,P in enumerate(pairs)}
        vals=[e.eqs(i,P)for P in pairs]
        ci=np.array([[pidx[P]for P in itertools.combinations(W,2)]for W in pool])
        matrices[i]=(np.asarray([x[0]for x,y in vals]),np.asarray([y[0]for x,y in vals]),ci)
    best={'rows':dict(rows),'beta':current.x[:-1].tolist(),'margin':float(current.x[-1]),'count':len(rows),'iteration':0}
    events=[];lp_calls=1;hist={};resets=0
    def attempt(candidate):
        nonlocal lp_calls
        lp_calls+=1;return e.solve(candidate)
    for it in range(a.iterations):
        if time.monotonic()-start>a.time_limit:break
        if len(rows)==n:break
        missing=[i for i in range(n) if i not in rows];i=int(rng.choice(missing))
        E,B,ci=matrices[i];scores=np.max(abs(E@current.x-B)[ci],axis=1)
        choices=list(np.argsort(scores)[:a.candidates*4]);choices+=list(rng.permutation(len(pools[i]))[:a.candidates*8])
        choices=list(dict.fromkeys(int(z)for z in choices));valid=[]
        for k in choices:
            W=pools[i][k]
            if compatible(i,W,rows,n):valid.append((scores[k],W))
        valid=sorted(valid,key=lambda x:x[0])[:a.candidates]
        failed=[];accepted=False
        for score,W in valid:
            trial={**rows,i:list(W)};r=attempt(trial)
            if r.success and r.x[-1]>1e-7:
                rows=trial;current=r;accepted=True;events.append({'iteration':it,'event':'ADD','center':i,'row':list(W),'count':len(rows),'margin':float(r.x[-1])});break
            if r.success:failed.append((float(r.x[-1]),W,r))
        if not accepted and failed:
            failed.sort(key=lambda x:-x[0]);_,W,r=failed[int(rng.integers(min(3,len(failed))))]
            trial={**rows,i:list(W)};removed=[]
            for step in range(3):
                
                if a.metric_closure:
                    keys=sorted(trial);costs=np.ones(len(keys))
                    # Exact quotient-derived rows have multi-source provenance;
                    # do not misattribute their duals to one selected row.
                else:
                    dual=r.eqlin.marginals[1:].reshape(-1,6);keys=sorted(trial);costs=np.sum(abs(dual),axis=1)
                elig=sorted([(float(costs[k]),j)for k,j in enumerate(keys)if j!=i],reverse=True)
                nz=[j for c,j in elig if c>1e-8][:4]
                if not nz:break
                j=int(rng.choice(nz));del trial[j];removed.append(j);r=attempt(trial)
                if r.success and r.x[-1]>1e-7:
                    loss=len(rows)-len(trial)
                    if loss<=0 or (len(trial)>=best['count']-2 and rng.random()<.12):
                        rows=trial;current=r;accepted=True;events.append({'iteration':it,'event':'SWAP','center':i,'row':list(W),'removed':removed,'count':len(rows),'margin':float(r.x[-1])})
                    break
                if not r.success:break
        if not accepted and rng.random()<.25:
            j=int(rng.choice(list(rows)));del rows[j];current=attempt(rows)
            events.append({'iteration':it,'event':'RELEASE','center':j,'count':len(rows)})
        if len(rows)<best['count']-3:
            rows={i:list(W)for i,W in best['rows'].items()}
            for j in rng.choice(list(rows),size=min(3,len(rows)),replace=False):del rows[int(j)]
            current=attempt(rows);resets+=1
        if not current.success or current.x[-1]<=1e-7:raise RuntimeError('accepted infeasible intermediate state')
        hist[len(rows)]=hist.get(len(rows),0)+1
        if len(rows)>best['count']:
            best={'rows':dict(rows),'beta':current.x[:-1].tolist(),'margin':float(current.x[-1]),'count':len(rows),'iteration':it}
            print('BEST',it,best['count'],'/',n,best['margin'],flush=True)
        if it%25==0:print('iteration',it,'current',len(rows),'best',best['count'],'LP',lp_calls,flush=True)
    else:it=a.iterations
    return {'classification':'NUMERICAL_FREE_ROW_ANGLE_HOLE_WALK','argv':sys.argv,'seed':a.seed,'n':n,'original_order':order,
            'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,'best':best,'events':events,
            'iterations_completed':it,'lp_calls':lp_calls,'resets':resets,'count_histogram':hist,'elapsed_seconds':time.monotonic()-start,
            'termination':'FULL_ANGLE_RELAXATION_FOUND' if best['count']==n else ('TIME_LIMIT' if time.monotonic()-start>a.time_limit else 'ITERATION_LIMIT'),
            'metric_closure':a.metric_closure,'all_existing_rows_allowed_to_change':True,'coordinate_symmetry_imposed':False,'carrier_imposed':False,
            'unrestricted_solution':False,'geometry_realization_not_claimed':True}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--orbits',type=int,default=4);p.add_argument('--iterations',type=int,default=2000)
    p.add_argument('--time-limit',type=float,default=120);p.add_argument('--candidates',type=int,default=12);p.add_argument('--seed',type=int,default=9709123)
    p.add_argument('--metric-closure',action='store_true');p.add_argument('--output',type=Path,required=True);a=p.parse_args();r=run(a);a.output.write_text(json.dumps(r,indent=2)+'\n');print({k:v for k,v in r.items()if k not in ['events','best']})

# Erdős Problem 97: n <= 8 Review Bundle

        This is the self-contained review bundle for the repository-local
        elementary `n <= 8` theorem and its selected-witness finite-case
        corroboration. It does not prove Erdős Problem #97 and does not claim
        a counterexample. The global problem remains open.

        Repository: https://github.com/davidiach/erdos97

        Source commit: `3fae8c0c0187666c5fa83986427744319810f2dc`

        The compact release note is
        `papers/release/small-counterexamples-erdos97-release.md` (also supplied
        as `papers/release/small-counterexamples-erdos97-release.pdf`). The
        one-page summary is `papers/release/n8-review-summary.md` (also supplied
        as `papers/release/n8-review-summary.pdf`). The shortest human proof is
        `docs/n8-geometric-proof.md`; its repository review record is
        `docs/n8-geometric-proof-audit-2026-07-09.md`.

        ## Integrity

        `BUNDLE_MANIFEST.json` records the source commit/tree, builder digest,
        declared Python/dependency environment, and every bundled file digest.
        `SHA256SUMS.txt` is the plain-text checksum list.

        ## Reproduction environment

        Use CPython 3.12.2. Install the pinned snapshot and this
        package without resolving newer dependencies:

        ```bash
        python -m pip install -r requirements-lock.txt
        python -m pip install -e . --no-deps
        ```

        Run the following commands from this directory:

        ```bash
        python scripts/independent_check_n8_artifacts.py --check --json
python scripts/enumerate_n8_incidence.py --summary
python scripts/analyze_n8_exact_survivors.py --check --json
python scripts/independent_n8_obstruction_recheck.py --check --json
python scripts/check_n8_class14_certificate.py --check --json
python scripts/check_n8_residual_certificates.py --check --json
python scripts/check_n8_survivors_smt.py --assert-clear --check-artifact data/certificates/n8_survivors_smt.json
        ```

        Citation metadata is in `CITATION.cff`. The split license and complete
        license texts are `LICENSE.md`, `LICENSE-CODE.md`, and
        `LICENSE-DOCS-DATA.md`.
